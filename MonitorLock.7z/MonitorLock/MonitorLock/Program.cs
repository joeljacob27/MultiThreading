﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MonitorLock
{
    class Program
    {
        static void Main(string[] args)
        {
            int ntasks = 0;
            int total_tasks = 5;
            Object _lockobj = new object();

            Parallel.For(0, total_tasks, (i, _parallelLoopState) =>
              {
                  
                  while(true)
                  {
                      try
                      {
                          if(Monitor.TryEnter(_lockobj))
                          {
                              Console.WriteLine("Lock Obtained by :" + "thread:" + i );
                              ntasks++;
                              Thread.Sleep(100);
                              Monitor.Exit(_lockobj);
                              break;
                          }
                          else
                          {
                              Thread.Sleep(200);
                              Console.WriteLine("Sleeping:" + "thread:" + i);
                          }
                      }
                      catch(Exception ex)
                      {

                      }
                  }
              });

            if(ntasks != total_tasks)
            {
                Console.WriteLine("SOme Wierd Error happened");
            }
            Console.ReadLine();
        }
    }
}
